--
-- PostgreSQL database dump
--

\restrict NAlwRgh7ehudReL1XvM6yGTaJvn8OjEP5I5uSJzQI0UH2pAZNQgWF8HQrXlnV8h

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NAlwRgh7ehudReL1XvM6yGTaJvn8OjEP5I5uSJzQI0UH2pAZNQgWF8HQrXlnV8h

