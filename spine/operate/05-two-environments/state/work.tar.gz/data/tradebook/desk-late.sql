-- 02:00:07 on 1 November: the desk amends three LCs while batch 42 is copying (§5.6).
BEGIN;
UPDATE lc_deals SET amount = 263000.00, status = 'AMENDED', source_version = 4, updated_at = '2026-11-01 02:00:07+00' WHERE lc_id = 'LC-2310';
INSERT INTO lc_amendments VALUES ('LC-2310', 4, 263000.00, 'AMENDED', '2026-11-01 02:00:07+00');
UPDATE lc_deals SET amount = 248000.00, status = 'AMENDED', source_version = 4, updated_at = '2026-11-01 02:00:07+00' WHERE lc_id = 'LC-2316';
INSERT INTO lc_amendments VALUES ('LC-2316', 4, 248000.00, 'AMENDED', '2026-11-01 02:00:07+00');
UPDATE lc_deals SET amount = 166000.00, status = 'AMENDED', source_version = 4, updated_at = '2026-11-01 02:00:07+00' WHERE lc_id = 'LC-2322';
INSERT INTO lc_amendments VALUES ('LC-2322', 4, 166000.00, 'AMENDED', '2026-11-01 02:00:07+00');
COMMIT;
