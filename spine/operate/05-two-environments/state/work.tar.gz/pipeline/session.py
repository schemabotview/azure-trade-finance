"""One SparkSession for every lc-exposure job, configured in one place."""
import logging
from glob import glob

from pyspark.sql import SparkSession


def spark_session() -> SparkSession:
    # PySpark also logs every error it raises (Spark's own: logs/spark.log)
    logging.getLogger("DataFrameQueryContextLogger").setLevel(logging.CRITICAL)
    return (
        SparkSession.builder
        .master("local[4]")  # Spark on this machine, 4 tasks at a time
        .appName("lc-exposure")
        .config("spark.driver.extraJavaOptions",
                "-Dlog4j2.configurationFile=conf/log4j2.properties")
        .config("spark.ui.showConsoleProgress", "false")
        .config("spark.sql.session.timeZone", "UTC")
        .config("spark.jars", ",".join(sorted(glob("jars/*.jar"))))
        # Delta Lake: its SQL commands, and tables that know they are Delta
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .getOrCreate()
    )
